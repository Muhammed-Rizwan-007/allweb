# app.py - Flask registration form and SQLAlchemy CRUD operations

from flask import Flask, render_template, redirect, url_for, flash
from flask_bootstrap import Bootstrap5
from flask_sqlalchemy import SQLAlchemy
from forms import RegistrationForm
from models import db, Student

app = Flask(__name__)
app.config['SECRET_KEY'] = 'a-long-random-secret-string'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

bootstrap = Bootstrap5(app)
db.init_app(app)

# Create the database tables
with app.app_context():
    db.create_all()


@app.route('/', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()

    if form.validate_on_submit():
        username = form.username.data
        flash(f'Account created for {username}!', 'success')
        return redirect(url_for('register'))

    return render_template('register.html', form=form)


@app.route('/add')
def add_student():
    student = Student(
        name='John',
        email='john@gmail.com'
    )
    db.session.add(student)
    db.session.commit()
    return 'Student Added'


@app.route('/students')
def get_students():
    students = Student.query.all()
    result = ''

    for student in students:
        result += (
            f'{student.id} - {student.name} - '
            f'{student.email}<br>'
        )

    return result or 'No Students Found'


@app.route('/update/<int:id>')
def update_student(id):
    student = Student.query.get(id)

    if student:
        student.name = 'Updated Name'
        db.session.commit()
        return 'Student Updated'

    return 'Student Not Found'


@app.route('/delete/<int:id>')
def delete_student(id):
    student = Student.query.get(id)

    if student:
        db.session.delete(student)
        db.session.commit()
        return 'Student Deleted'

    return 'Student Not Found'


if __name__ == '__main__':
    app.run(debug=True)
