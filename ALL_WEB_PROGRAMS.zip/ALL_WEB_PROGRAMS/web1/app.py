# Flask application with static and dynamic routes

from flask import Flask

app = Flask(__name__)

# STATIC ROUTES
@app.route('/')
def home():
    return '<h1>Welcome to my Flask app!</h1>'

@app.route('/about')
def about():
    return '<p>This is a simple Flask application.</p>'

# DYNAMIC ROUTES
@app.route('/user/<name>')
def greet_user(name):
    return f'<h2>Hello, {name}!</h2>'

@app.route('/square/<int:number>')
def square(number):
    return f'<h3>The square of {number} is {number * number}</h3>'

if __name__ == '__main__':
    app.run(debug=True)
