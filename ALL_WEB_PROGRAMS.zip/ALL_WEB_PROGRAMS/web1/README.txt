WEB1 - Flask Setup and Routing

This project implements the Flask practical shown in the supplied textbook photos.

Routes:
  http://127.0.0.1:5000/             Welcome message
  http://127.0.0.1:5000/about        About message
  http://127.0.0.1:5000/user/Rizwan  Dynamic greeting
  http://127.0.0.1:5000/square/5     Square of 5

RUN ON WINDOWS:
1. Install Python and make sure "Add Python to PATH" is selected.
2. Extract the web1 folder.
3. Double-click setup.bat. This creates the Windows-compatible venv folder
   and installs Flask.
4. Double-click run.bat.
5. Open http://127.0.0.1:5000/ in your browser.
6. Press Ctrl+C in the terminal to stop the server.

You can also run manually in Command Prompt:
  python -m venv venv
  venv\Scripts\activate
  pip install -r requirements.txt
  python app.py

Note:
The venv is created on your Windows computer by setup.bat so it uses the
correct Windows executables and paths. The source project and dependency
list are included in this folder.
