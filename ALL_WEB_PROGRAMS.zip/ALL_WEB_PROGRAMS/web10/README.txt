WEB10 - Django Student CRUD using Generic Class-Based Views

Features:
- READ: display all student records
- CREATE: add a student
- UPDATE: edit an existing student
- DELETE: confirm and remove a student

Student fields: name, email, course, age.

Create your virtual environment manually, then run these commands from this folder:

  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  python manage.py makemigrations pages
  python manage.py migrate
  python manage.py runserver

Open:
  http://127.0.0.1:8000/

The virtual environment is not included. The initial database migration is generated
on your computer with the makemigrations command above.
