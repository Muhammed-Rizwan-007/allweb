# pages/views.py - generic class-based views for CRUD
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from .models import Student


# READ: list all students
class StudentListView(ListView):
    model = Student
    template_name = 'student_list.html'
    context_object_name = 'students'


# CREATE: add a new student
class StudentCreateView(CreateView):
    model = Student
    template_name = 'student_form.html'
    fields = ['name', 'email', 'course', 'age']
    success_url = reverse_lazy('student_list')


# UPDATE: edit an existing student
class StudentUpdateView(UpdateView):
    model = Student
    template_name = 'student_form.html'
    fields = ['name', 'email', 'course', 'age']
    success_url = reverse_lazy('student_list')


# DELETE: remove a student
class StudentDeleteView(DeleteView):
    model = Student
    template_name = 'student_confirm_delete.html'
    success_url = reverse_lazy('student_list')
