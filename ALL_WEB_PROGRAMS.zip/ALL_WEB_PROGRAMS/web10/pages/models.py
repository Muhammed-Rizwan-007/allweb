# pages/models.py - a database model
from django.db import models


class Student(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    course = models.CharField(max_length=50)
    age = models.IntegerField()

    def __str__(self):
        return self.name
