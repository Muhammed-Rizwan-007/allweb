WEB14 - Django Protected Posts with Login Authentication

This practical extends WEB13. It adds a Post model linked to the custom user
model and protects the post list and add-post page so only logged-in users
can access them.

SETUP (run from the web14 folder)
  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  python manage.py makemigrations accounts
  python manage.py migrate
  python manage.py runserver

URLS
  Home:       http://127.0.0.1:8000/
  Login:      http://127.0.0.1:8000/login/
  Signup:     http://127.0.0.1:8000/signup/
  Posts:      http://127.0.0.1:8000/posts/
  Add post:   http://127.0.0.1:8000/posts/add/

USAGE
1. Sign up for an account and log in.
2. Open /posts/ to view the posts.
3. Select Add Post to create a post.
4. Log out and open /posts/ again; Django redirects you to login.

The author field is automatically set to the currently logged-in user.
The Post model uses a ForeignKey relationship to CustomUser.
