# app.py - secure form, POST handling, flashed messages

from flask import Flask, flash, render_template, redirect, url_for
from flask_bootstrap import Bootstrap5
from forms import RegistrationForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'a-long-random-secret-string'

bootstrap = Bootstrap5(app)


@app.route('/', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()

    if form.validate_on_submit():
        username = form.username.data
        flash(f'Account created for {username}!', 'success')
        return redirect(url_for('register'))

    return render_template('register.html', form=form)


if __name__ == '__main__':
    app.run(debug=True)
