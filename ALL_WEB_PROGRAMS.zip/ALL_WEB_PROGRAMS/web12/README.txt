WEB12 - Django User Authentication (Sign Up, Login and Logout)

This practical uses the CustomUser model and provides:
- User sign up with username, email, phone, age and password
- Login using Django's built-in LoginView
- A home page that displays the current login state
- Logout using a POST form

SETUP
Run these commands from the web12 folder:

  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  python manage.py makemigrations accounts
  python manage.py migrate
  python manage.py runserver

Open:
  http://127.0.0.1:8000/

Create a user through the Sign Up link. After signing up, the user is
redirected to the login page. Log in to see the authenticated home page.
Use the Log Out button to end the session.

NOTES
- AUTH_USER_MODEL is set to accounts.CustomUser before the first migration.
- The custom signup form extends Django's UserCreationForm, so it includes
  password and password confirmation fields.
- Logout is submitted with POST and includes a CSRF token.
- This is a fresh project. Do not run migrations before configuring the
  custom user model.
