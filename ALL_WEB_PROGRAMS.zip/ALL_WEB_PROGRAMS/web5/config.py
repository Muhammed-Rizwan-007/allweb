# config.py - application configuration

import os


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'a-long-random-secret')

    # Mail server settings
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 587))
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_USERNAME') or 'noreply@example.com'

    # Allow the project to run without SMTP credentials.
    # Set MAIL_USERNAME and MAIL_PASSWORD to send real emails.
    MAIL_SUPPRESS_SEND = not bool(MAIL_USERNAME and MAIL_PASSWORD)
