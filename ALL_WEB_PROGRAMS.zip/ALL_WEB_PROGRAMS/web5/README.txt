WEB5 - Flask Application Factory, Blueprints and Email

Folder structure:
  config.py
  run.py
  requirements.txt
  app/
    __init__.py
    email.py
    main/
      __init__.py
      routes.py
    auth/
      __init__.py
      routes.py

Install and run (after creating/activating your own venv):
  pip install -r requirements.txt
  python run.py

Open:
  http://127.0.0.1:5000/        Main blueprint home page
  http://127.0.0.1:5000/auth/register   Registration demo and welcome email

Email configuration:
The project starts without email credentials. In that case, Flask-Mail
suppresses sending so you can test the routes without an SMTP account.

To send a real email, set these environment variables before running:
  MAIL_USERNAME
  MAIL_PASSWORD

For Gmail, use a Google App Password (with 2-Step Verification enabled),
not your normal Gmail password. The recipient in the practical is the
example address student@example.com; change it in app/auth/routes.py
to an email address you control before sending real mail.

The project does not include a virtual environment. Create it manually.
