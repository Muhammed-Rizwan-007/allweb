WEB9 - Django Model and Admin Panel

This practical creates a Student database model and registers it in Django Admin.

Create your virtual environment manually, then run these commands in the project folder:

  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt

Create the database migration and apply it:

  python manage.py makemigrations pages
  python manage.py migrate

Create an admin login:

  python manage.py createsuperuser

Enter a username, email and password when prompted.

Start the development server:

  python manage.py runserver

Open the admin panel:

  http://127.0.0.1:8000/admin/

Log in, then add, view or edit Student records.

The virtual environment is not included; create it manually.
