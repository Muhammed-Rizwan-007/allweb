# pages/admin.py - register models with the admin panel
from django.contrib import admin
from .models import Student

admin.site.register(Student)
