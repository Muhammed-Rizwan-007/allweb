WEB11 - Django Custom User Model

This practical creates a custom Django user model with three extra fields:
- phone
- address
- age

The custom model inherits from AbstractUser and is registered in the Django
administration panel.

IMPORTANT:
AUTH_USER_MODEL is configured in myproject/settings.py before the first
database migration. For a fresh project, do not run migrate before setting
up this custom user model.

Run these commands from the web11 folder:

  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  python manage.py makemigrations accounts
  python manage.py migrate
  python manage.py createsuperuser
  python manage.py runserver

Open the admin panel:
  http://127.0.0.1:8000/admin/

Log in with the superuser account. Open a user record to see the custom
fields alongside Django's built-in user fields.

The virtual environment and generated database are not included.
