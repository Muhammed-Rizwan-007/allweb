WEB8 - Django Class-Based Views

Create and activate your own virtual environment, then run:
  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  python manage.py migrate
  python manage.py runserver

Pages:
  http://127.0.0.1:8000/        Home Page
  http://127.0.0.1:8000/about/  About Page

The venv is not included; create it manually.
