WEB13 - Django Password Change and Password Reset

This practical extends the authentication project with Django's built-in
password change and password reset views.

SETUP (run from the web13 folder)
  python -m venv venv
  .\venv\Scripts\Activate.ps1
  pip install -r requirements.txt
  python manage.py makemigrations accounts
  python manage.py migrate
  python manage.py runserver

URLS
  Home:            http://127.0.0.1:8000/
  Login:           http://127.0.0.1:8000/login/
  Password change: http://127.0.0.1:8000/password-change/ (must be logged in)
  Password reset:  http://127.0.0.1:8000/password-reset/

For password reset, enter the email address of an existing account.
The reset email and link are printed in the terminal.

Includes signup, login, logout and the custom user model from WEB12.
The console email backend is intended for local development testing.
