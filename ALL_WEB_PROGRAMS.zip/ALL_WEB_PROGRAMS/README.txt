ALL WEB PROGRAMS

This main folder contains the separate program folders WEB1 through WEB14
and the separate DJANGO_DEPLOYMENT folder.

Each program remains in its own folder. No program files have been merged
or overwritten.
