Django deployment configuration files transcribed from the supplied textbook images (pages 262-263).

Files:
- .env: environment variable placeholders
- .gitignore: files and folders to exclude from version control
- settings_changes.txt: settings.py changes shown in the images
- Procfile: Gunicorn web process command
- runtime.txt: Python runtime version

Note: settings_changes.txt contains the shown configuration changes, not a complete settings.py file.
The .env file contains a placeholder secret key. Replace it with a real secret key before deployment.
